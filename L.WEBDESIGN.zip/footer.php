</div>
<div id="footer">
    <footer class="footer__box">
        <ul class="footer__list">
            <li><a href="/">TOP</a></li>
            <li><a href="/sample-page/about">ABOUT</a></li>
            <li><a href="/sample-page/service">SERVICE</a></li>
            <li><a href="/sample-page/contact">CONTACT</a></li>
        </ul>
    </footer>
    <p class="footer__copyright">COPYRIGHT © L.WEB DESIGN</p>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js"></script>
    <script src="https://unpkg.com/vue-scrollto"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/main.js"></script>
<?php wp_footer(); ?>
</body>

</html>
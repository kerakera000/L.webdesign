</div>
<div id="footer">
    <footer class="footer__box">
        <ul class="footer__list">
            <li><a href="#">TOP</a></li>
            <li><a href="#">ABOUT</a></li>
            <li><a href="#">SERVICE</a></li>
            <li><a href="#">CONTACT</a></li>
        </ul>
    </footer>
    <p class="footer__copyright">COPYRIGHT © L.WEB DESIGN</p>
    </div>

<?php wp_footer(); ?>
</body>

</html>
<?php get_header(); ?>

<div id="section1">
        <div class="section1__titlebox">
            <h2 class="section1__title">L.WEB DESIGN</h2>
            <div class="section1__underline"></div>
            <p class="section1__text">Milk tea is my energy source</p>
        </div>
        <div class="section1__mousebox">
            <div class="section1__line"></div>
            <div class="section1__mouseicon"></div>
        </div>
</div>


<?php get_footer(); ?>
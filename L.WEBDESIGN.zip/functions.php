<?php

// インストール時に動作するソースコードを記述します。
// テーマで使用するカテゴリを自動追加する等。
// 参考: https://github.com/WillMake-Inc/2020_05_11_palkour_hp/blob/master/palkour_hp/functions.php

// TGM Plugin Activationを利用する場合は以下のコメントアウトを外してください。
//include(get_template_directory() . '/resources/activate-tgmpa.php');

// 閲覧数カウントを有効化する場合以下のコメントアウトを外してください。
//include(get_template_directory() . '/resources/activate-viewcount.php)